package com.example.calculateur2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText editText;
    private ProgressBar progressBar;
    private double arg1, arg2, result;
    private String operation = "";
    // Méthode pour désactiver tous les boutons
    private void disableButtons() {
        // Désactiver tous les boutons de calcul
        findViewById(R.id.btn0).setEnabled(false);
        findViewById(R.id.btn1).setEnabled(false);
        findViewById(R.id.btn2).setEnabled(false);
        findViewById(R.id.btn3).setEnabled(false);
        findViewById(R.id.btn4).setEnabled(false);
        findViewById(R.id.btn5).setEnabled(false);
        findViewById(R.id.btn6).setEnabled(false);
        findViewById(R.id.btn7).setEnabled(false);
        findViewById(R.id.btn8).setEnabled(false);
        findViewById(R.id.btn9).setEnabled(false);
        findViewById(R.id.btnPlus).setEnabled(false);
        findViewById(R.id.btnMinus).setEnabled(false);
        findViewById(R.id.btnMultiply).setEnabled(false);
        findViewById(R.id.btnDivide).setEnabled(false);
        findViewById(R.id.btnClear).setEnabled(false);
        findViewById(R.id.btnEqual).setEnabled(false);
        findViewById(R.id.btnFactorial).setEnabled(false);
    }

    // Méthode pour réactiver tous les boutons
    private void enableButtons() {
        // Réactiver tous les boutons de calcul
        findViewById(R.id.btn0).setEnabled(true);
        findViewById(R.id.btn1).setEnabled(true);
        findViewById(R.id.btn2).setEnabled(true);
        findViewById(R.id.btn3).setEnabled(true);
        findViewById(R.id.btn4).setEnabled(true);
        findViewById(R.id.btn5).setEnabled(true);
        findViewById(R.id.btn6).setEnabled(true);
        findViewById(R.id.btn7).setEnabled(true);
        findViewById(R.id.btn8).setEnabled(true);
        findViewById(R.id.btn9).setEnabled(true);
        findViewById(R.id.btnPlus).setEnabled(true);
        findViewById(R.id.btnMinus).setEnabled(true);
        findViewById(R.id.btnMultiply).setEnabled(true);
        findViewById(R.id.btnDivide).setEnabled(true);
        findViewById(R.id.btnClear).setEnabled(true);
        findViewById(R.id.btnEqual).setEnabled(true);
        findViewById(R.id.btnFactorial).setEnabled(true);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editText = findViewById(R.id.editText);
        progressBar = findViewById(R.id.progressBar);

        IntentFilter enableButtonsFilter = new IntentFilter("com.example.calculateur2.ENABLE_BUTTONS");
        registerReceiver(enableButtonsReceiver, enableButtonsFilter);


        View.OnClickListener numberClickListener = v -> {
            Button button = (Button) v;
            editText.append(button.getText().toString());
        };

        int[] numberButtonIds = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        };

        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(numberClickListener);
        }


        findViewById(R.id.btnClear).setOnClickListener(v -> {
            editText.setText("");
            arg1 = arg2 = result = 0;
            operation = "";
        });


        View.OnClickListener operationClickListener = v -> {
            Button button = (Button) v;
            operation = button.getText().toString();
            arg1 = Double.parseDouble(editText.getText().toString());
            editText.setText("");
        };

        findViewById(R.id.btnPlus).setOnClickListener(operationClickListener);
        findViewById(R.id.btnMinus).setOnClickListener(operationClickListener);
        findViewById(R.id.btnMultiply).setOnClickListener(operationClickListener);
        findViewById(R.id.btnDivide).setOnClickListener(operationClickListener);


        findViewById(R.id.btnEqual).setOnClickListener(v -> {
            arg2 = Double.parseDouble(editText.getText().toString());
            switch (operation) {
                case "+": result = arg1 + arg2; break;
                case "-": result = arg1 - arg2; break;
                case "x": result = arg1 * arg2; break;
                case "/": result = arg2 != 0 ? arg1 / arg2 : 0; break;
            }
            editText.setText(String.valueOf(result));
        });


        findViewById(R.id.btnFactorial).setOnClickListener(v -> {
            try {
                int n = Integer.parseInt(editText.getText().toString());


                disableButtons();


                Intent intent = new Intent(this, FactorialIntentService.class);
                intent.putExtra("number", n);
                startService(intent);


                progressBar.setVisibility(View.VISIBLE);
                editText.setText("");

            } catch (NumberFormatException e) {
                editText.setText("Erreur");
            }
        });



        IntentFilter progressFilter = new IntentFilter("com.example.calculateur2.PROGRESS_UPDATE");
        registerReceiver(progressReceiver, progressFilter);


        IntentFilter resultFilter = new IntentFilter("com.example.calculateur2.RESULT");
        registerReceiver(resultReceiver, resultFilter);
    }


    private final BroadcastReceiver progressReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int progress = intent.getIntExtra("progress", 0);
            progressBar.setProgress(progress); // Met à jour la ProgressBar
        }
    };


    private final BroadcastReceiver resultReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String result = intent.getStringExtra("result");
            progressBar.setVisibility(View.GONE);


            editText.setText(result);
        }
    };
    private final BroadcastReceiver enableButtonsReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            enableButtons();
            progressBar.setVisibility(View.GONE);
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(progressReceiver);
        unregisterReceiver(resultReceiver);
        unregisterReceiver(enableButtonsReceiver);
    }


}


