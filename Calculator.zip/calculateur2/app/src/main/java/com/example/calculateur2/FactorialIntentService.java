package com.example.calculateur2;

import android.app.IntentService;
import android.content.Intent;

public class FactorialIntentService extends IntentService {
    public FactorialIntentService() {
        super("FactorialIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        int number = intent.getIntExtra("number", -1);


        if (number > 170) {

            sendResult("Inf");
            return;
        }

        double factorial = 1;
        for (int i = 1; i <= number; i++) {
            factorial *= i;


            int progress = (int) (((float) i / number) * 100);
            sendProgressUpdate(progress);


            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


        sendResult(String.valueOf(factorial));
    }


    private void sendProgressUpdate(int progress) {
        Intent progressIntent = new Intent("com.example.calculateur2.PROGRESS_UPDATE");
        progressIntent.putExtra("progress", progress);
        sendBroadcast(progressIntent);
    }


    private void sendResult(String result) {
        Intent resultIntent = new Intent("com.example.calculateur2.RESULT");
        resultIntent.putExtra("result", result);
        sendBroadcast(resultIntent);


        Intent enableButtonsIntent = new Intent("com.example.calculateur2.ENABLE_BUTTONS");
        sendBroadcast(enableButtonsIntent);
    }

}



